import React from 'react'

const second=props=>(
    <div>
        <h1>second</h1>
    </div>
)

export default second