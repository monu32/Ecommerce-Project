import React,{Component} from 'react'
import classes from './Input.module.css'

class input extends Component
{        
    render()
    {
        let checkValid=classes.Valid
        if(!this.props.valid)
            checkValid=classes.Invalid
        if(!this.props.fieldTouch)
            checkValid=""
        let inputElement
        switch(this.props.InputType)
        {
            case('input'):
                inputElement=<input 
                className={[classes.InputClass,checkValid].join(' ')}
                type={this.props.type} 
                name={this.props.name} 
                placeholder={this.props.placeholder} 
                onChange={this.props.changed}/>
                break

            case('textarea'):
                inputElement=<textarea
                className={[classes.TextAreaClass,checkValid].join(' ')}
                type={this.props.type} 
                name={this.props.name} 
                placeholder={this.props.placeholder} 
                onChange={this.props.changed}/>                
                break

            case('select'):
                inputElement=<select
                type={this.props.type} 
                name={this.props.name} 
                onChange={this.props.changed}>                                
                <option value={true}>YES</option>
                <option value={false}>NO</option>
                </select>
                break

            case('file'):
                inputElement=<input 
                type="file"
                onChange={this.props.changed}/>
                break
            default:
                break
        } 
        return(
            <div>
                <label className={classes.Label}>{this.props.name}</label>
                {inputElement}
            </div>
        )
    }
}

export default input