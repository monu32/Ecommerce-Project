import * as actionTypes from './actionTypes';
import axios from 'axios'

export const updateCartSuccess=(cart)=>
{
    return {
        type:actionTypes.UPDATE_PRODUCT_IN_CART,
        cart:cart
    }
}

export const setCartSuccess=(cart)=>
{
    return{
        type:actionTypes.SET_CART_SUCCESS,
        cart:cart
    }
}

export const setCartItems=()=>
{
        return dispatch => {
            axios.get('/api/user/getCartItems')
                .then( response => {
                    dispatch(setCartSuccess(response.data))
               })
                .catch( error => {
                })
        }    
}

export const emptyCartSuccess=()=>
{
    return{
        type:actionTypes.EMPTY_CART_SUCCESS
    }
}

export const EmptyCart=()=>{
    return dispatch=>{
        axios.patch('/api/user/removeCartItem')
        .then(response=>{
            dispatch(emptyCartSuccess())
        })
        .catch(error=>{
        })
    }
}

export const UpdateProductInCart=(product,status)=> 
{
    let storeId=product._id
    if(product.productId)
        storeId=product.productId

    const cartProduct={
        productName:product.productName,
        image:product.image,
        productId:storeId
    }
    return dispatch => {
        axios.post('/api/user/updateCart/'+status,cartProduct)
            .then( response => {
                dispatch(updateCartSuccess(response.data))
           })
            .catch( error => {
                alert("Please Login...")
            })
    }
}