import * as actionTypes from './actionTypes';
import axios from 'axios'

export const udpateOrderSuccess=(orders)=>
{
    return {
        type:actionTypes.UPDATE_ORDER_SUCCESS,
        orders:orders
    }
}

export const setOrderSuccess=(orders)=>
{
    return {
        type:actionTypes.SET_ORDERS_SUCCESS,
        orders:orders
    }
}


export const updateOrdersList=(cart)=> 
{
    const id=cart.productId
    const quantity=cart.quantity
    const image=cart.image  

        return dispatch=>{
            axios.patch('/api/user/updateOrdersList/'+id+'/'+quantity,{image})
            .then(res=>{
                dispatch(udpateOrderSuccess(res.data.orders))
            })
            .catch(error=>{
                alert("There is error,Please try after some time")
            })
        }
}

export const setOrdersList=()=> 
{
        return dispatch=>{
            axios.get('/api/user/getAllOrders')
            .then(res=>{
                dispatch(setOrderSuccess(res.data))
            })
            .catch(error=>{
            })
        }
}
