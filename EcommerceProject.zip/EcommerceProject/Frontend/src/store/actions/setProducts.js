import * as actionTypes from './actionTypes';
import axios from 'axios'

export const setProductsSuccess=(products,categories)=>
{
    return {
        type:actionTypes.SET_PRODUCTS_SUCCESS,
        payload:{
            products,
            categories
        }
    }
}

export const setProductsFailed=()=>
{
    return {
        type: actionTypes.SET_PRODUCTS_FAILED
    }
}

export const setProducts=()=> 
{
    return dispatch => {
        axios.get('/api/product/getProducts')
            .then( response => {
                let checkCategory=[]
            
                for(let index in response.data)
                {
                    let category=response.data[index].category
                    checkCategory.push(category)
                }
                checkCategory=checkCategory.filter((value,index)=>checkCategory.indexOf(value)===index)
                let ProductsArray=[]
                for(let categoryIndex in checkCategory)
                {
                    let tempArray=[]
                    for(let productIndex in response.data)
                    {
                        if(response.data[productIndex].category===checkCategory[categoryIndex])
                        {
                            const data=response.data[productIndex]
                            tempArray.push(data)
                        }              
                    }
                    const category=checkCategory[categoryIndex]
                    ProductsArray.push({[category]:tempArray})
                }
            dispatch(setProductsSuccess(ProductsArray,checkCategory))
            })
            .catch( error => {
            })
    }
}