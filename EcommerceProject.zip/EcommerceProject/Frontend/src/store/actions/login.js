import * as actionTypes from './actionTypes';
import axios from 'axios'

export const userLoginSuccess=(email)=>
{
    return {
        type:actionTypes.CHECK_LOGIN_SUCCESS,
        email:email
    }
}

export const checkUserLogin=()=>
{
    return dispatch => {
        axios.get('/api/user/getUser')
            .then( response => {
                dispatch(userLoginSuccess(response.data.email))
           })
            .catch( error => {
            })
    }
}

