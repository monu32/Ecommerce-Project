import * as actionTypes from '../actions/actionTypes';

const initialState = 
{
    Products:[],
    Categories:[]
}

const setProductsSuccess=(state,action)=>
{
    const products=action.payload.products
    const categories=action.payload.categories
    return { 
        ...state,
        Products:products,
        Categories:categories
    }
}

const addNewCategory=(state,action)=>
{
    const category=action.category
    const updatedCategory=state.Categories
    if(!updatedCategory.includes(category))
        updatedCategory.push(category)
    console.log(updatedCategory)
    return {
        Category:updatedCategory
    }
}

const reducer = ( state = initialState, action ) =>
{
    switch(action.type)
     {
        case actionTypes.SET_PRODUCTS_SUCCESS: return setProductsSuccess(state,action)
        case actionTypes.ADD_NEW_CATEGORY: return addNewCategory(state,action)
        default: return state;
    }
};

export default reducer;