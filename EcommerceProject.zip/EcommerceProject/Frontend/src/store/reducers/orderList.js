import * as actionTypes from '../actions/actionTypes';
import { setCartSuccess } from '../actions/cart';

const initialState = 
{
    Orders:[]
}

const udpateOrderSuccess=(state,action)=>
{
    const orders=action.orders
    return { 
        ...state,
        Orders:orders
    }
}

const setOrderSuccess=(state,action)=>
{
    const orders=action.orders
    return { 
        ...state,
        Orders:orders
    }
}


const reducer = ( state = initialState, action ) =>
{
    switch(action.type)
     {
        case actionTypes.UPDATE_ORDER_SUCCESS: return udpateOrderSuccess(state,action)
        case actionTypes.SET_ORDERS_SUCCESS: return setOrderSuccess(state,action)
        default: return state;
    }
};

export default reducer;