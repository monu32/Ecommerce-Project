import * as actionTypes from '../actions/actionTypes';

const initialState = 
{
    Cart:[]
}

const updateCart=(state,action)=>
{
    return {
        Cart:action.cart
    }
}

const setCart=(state,action)=>
{
    return {
        Cart:action.cart
    }
}

const emptyCart=(state,action)=>{
    return{
        Cart:[]
    }
}

const reducer=(state=initialState,action) =>
{
    switch(action.type)
     {
        case actionTypes.UPDATE_PRODUCT_IN_CART: return updateCart(state,action)
        case actionTypes.SET_CART_SUCCESS: return setCart(state,action)
        case actionTypes.EMPTY_CART_SUCCESS: return emptyCart(state,action)
        default: return state;
    }
};

export default reducer;