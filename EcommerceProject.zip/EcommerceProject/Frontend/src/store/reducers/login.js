import * as actionTypes from '../actions/actionTypes';

const initialState = 
{
    user:false,
    admin:false
}

const checkLoginSuccess=(state,action)=>
{
    if(action.email==="monuecommerce@gmail.com") 
    {
        return {
            ...state,
            admin:true
        }
    }    
   else 
   {
       return {
           ...state,
           user:true
       }
   } 
}

const reducer=(state=initialState,action)=>
{
    switch(action.type)
     {
        case actionTypes.CHECK_LOGIN_SUCCESS: return checkLoginSuccess(state,action)
        default: return state;
    }
};

export default reducer;