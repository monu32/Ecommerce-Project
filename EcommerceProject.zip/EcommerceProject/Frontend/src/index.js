import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import * as serviceWorker from './serviceWorker';
import {BrowserRouter} from 'react-router-dom'
import productReducer from './store/reducers/setProducts'
import cartReducer from './store/reducers/cart'
import ordersReducer from './store/reducers/orderList'
import loginReducer from './store/reducers/login'

import {createStore,applyMiddleware,combineReducers} from 'redux';
import {Provider} from 'react-redux'
import thunk from 'redux-thunk';

const rootReducer=combineReducers({
    productReducer:productReducer,
    cartReducer:cartReducer,
    ordersReducer:ordersReducer,
    loginReducer:loginReducer,
})

const store = createStore(rootReducer,applyMiddleware(thunk))

const app= 
(
    <Provider store={store}>
        <BrowserRouter>
            <App />
        </BrowserRouter>
    </Provider>
);

ReactDOM.render(app,document.getElementById('root'));

serviceWorker.unregister();
