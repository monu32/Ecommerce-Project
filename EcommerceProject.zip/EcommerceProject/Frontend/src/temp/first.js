import React,{Component} from 'react'
import Aux from './Aux'
class first extends Component{
    render(){
        return(
            <div>
                {this.props.name}
            </div>
        )
    }   
}

export default Aux(first)