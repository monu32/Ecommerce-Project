import React,{Component} from 'react'
import Aux from './Aux'
class second extends Component{
    render(){
        return(
            <div>
                {this.props.name}
            </div>
        )
    }   
}

export default Aux(second)