import React from 'react'

const first=props=>(
    <div>
        <h1>First</h1>
        <h1>First</h1>
        <h1>First</h1>
        <h1>First</h1>

    </div>
)

export default first