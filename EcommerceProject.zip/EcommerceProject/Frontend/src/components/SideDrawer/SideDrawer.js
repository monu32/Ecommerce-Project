import React from 'react'
import Logo from '../Logo/Logo'
import NavigationBar from '../NavigationBar/NavigationBar'
import classes from './SideDrawer.module.css'
import Backdrop from '../../Backdrop/Backdrop'
import CategoriesNavigationItem from '../CategoriesBar/CategoriesNavigationItem/CategoriesNavigationItem'
import SideDrawerFunctions from '../Admin/SideDrawerFunctions'

const SideDrawer=(props)=>{
    let combineClasses=[classes.SideDrawer,classes.Close]
    if(props.open)
        combineClasses=[classes.SideDrawer,classes.Open]
    return (
        <div>
            <Backdrop show={props.open} clicked={props.closed}/>
            <div className={combineClasses.join(' ')}>
                <Logo height="11%"/>
                <nav className={classes.DesktopOnly}>
                    <NavigationBar/>
                    <CategoriesNavigationItem/>
                </nav>
                <SideDrawerFunctions/>
            </div>
        </div>
    )
}

export default SideDrawer