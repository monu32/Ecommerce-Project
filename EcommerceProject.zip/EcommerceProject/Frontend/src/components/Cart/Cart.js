import React,{Component} from 'react'
import { connect } from 'react-redux';

import classes from './Cart.module.css'
import NavigatonItem from '../../components/NavigationBar/NavigationItem/NavigationItem'
import * as actions from '../../store/actions/index'

class Cart extends Component
{
    render()
    {
        let products=this.props.products.map(product=>(
                <div className={classes.productInformation}>
                    <img src={product.image}width="200" height="250" alt={product.image}/>
                    <p>Product Name : {product.productName}</p>
                    <p>Quantity : {product.quantity}</p>
                    <button onClick={(productParameter,status)=>this.props.addCart(product,"add")}>Add to Cart (+)</button>
                    <button onClick={(productParameter,status)=>this.props.addCart(product,"remove")}>Remove from Cart (-)</button>
                </div>
            ))   
    return(
            <div className={classes.OuterCart}>
                <div className={classes.Cart}>
                    {products}
                </div>
                <div className={classes.checkoutLink}>
                    <NavigatonItem link="/checkout">Checkout</NavigatonItem>
                </div>
            </div>
    )
}
}

const mapStateToProps = state => {
    return {
        cart:state.cartReducer.Cart,
    }
}

const mapDispatchToProps = dispatch => {
    return {
        setCartItems:()=>dispatch(actions.setCartItems())
    }
}

export default connect(mapStateToProps,mapDispatchToProps)(Cart)