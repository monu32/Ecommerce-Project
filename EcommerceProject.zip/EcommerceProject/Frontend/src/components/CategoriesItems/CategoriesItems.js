import React,{Component} from 'react'
import classes from './CategoriesItems.module.css'
import {Route} from 'react-router-dom'
import CategoriesItem from './CategoriesItem/CategoriesItem'
import { connect } from 'react-redux';

import Cart from '../Cart/Cart'
import Checkout from '../../components/Checkout/Checkout'
import Shipping from '../././Shipping/Shipping'
import AddNewProduct from '../Admin/AddNewProduct/AddNewProduct'
import UpdateProduct from '../Admin/UpdateProduct/UpdateProduct'
import DeleteProduct from '../Admin/DeleteProduct/DeleteProduct'
import OrdersList from '../OrdersList/OrdersList'
import Home from '../../components/Home/Home'
import Login from '../Auth/login'
import Logout from '../Auth/logout'

import * as actions from '../../store/actions/index';

class CategoriesItems extends Component{

componentDidMount()
{
    this.props.setProducts()
    this.props.checkUserLogin()
    this.props.setCartItems()
    this.props.setOrdersList()    
}

    render(){
        let store=this.props.Categories.map(category=>(
            (<Route path={`/${category}`} exact component={()=><CategoriesItem products={this.props.Products} category={category} addCart={(product,status)=>this.props.UpdateProductInCart(product,status)} addCart={(product,status)=>this.props.UpdateProductInCart(product,status)}/>}/>)    
        ))
        return (
            <div className={classes.CategoriesItems}>
                    {store}
                        <Route path="/" exact component={()=><Home/>}/>
                        <Route path="/cart" exact component={()=><Cart products={this.props.cart} addCart={(product,status)=>this.props.UpdateProductInCart(product,status)} addCart={(product,status)=>this.props.UpdateProductInCart(product,status)}/>}/>
                        <Route path="/checkout" exact component={()=><Checkout products={this.props.cart}/>}/>
                        <Route path="/shipping" exact component={Shipping}/>
                        <Route path="/addNewProduct" exact component={AddNewProduct}/>
                        <Route path="/updateProduct/:id" exact component={UpdateProduct}/>
                        <Route path="/DeleteProduct/:id" exact component={DeleteProduct}/>
                        <Route path="/Orders" exact component={OrdersList}/>
                        <Route path="/login" exact component={Login}/>
                        <Route path="/logout" exact component={Logout}/>
            </div>
        )
    }
}

const mapStateToProps = state => {
    return {
        Products:state.productReducer.Products,
        cart:state.cartReducer.Cart,
        Categories:state.productReducer.Categories,
        checkAdminAuth:state.loginReducer.admin,
        checkUserAuth:state.loginReducer.user
    }
}

const mapDispatchToProps = dispatch => {
    return {
        setProducts:()=>dispatch(actions.setProducts()),
        UpdateProductInCart:(product,status)=>dispatch(actions.UpdateProductInCart(product,status)),
        setCartItems:()=>dispatch(actions.setCartItems()),
        checkUserLogin:()=>dispatch(actions.checkUserLogin()),
        setOrdersList:()=>dispatch(actions.setOrdersList())
    }
}

export default connect(mapStateToProps,mapDispatchToProps)(CategoriesItems)

