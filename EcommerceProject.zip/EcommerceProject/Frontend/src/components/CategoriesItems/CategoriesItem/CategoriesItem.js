import React,{Component} from 'react'
import { connect } from 'react-redux';

import classes from './CategoriesItem.module.css'
import {Link} from 'react-router-dom'
// Must set id in key to remove the duplication

class CategoriesItem extends Component
{
render()
{
    let products=this.props.products
    let FilteredProduct=[]  
    for(let index in products)
    {
            let category=this.props.category
            if((Object.keys(products[index])[0])===category)
                FilteredProduct=products[index][category]
    }

    products=FilteredProduct.map(product=>this.props.checkAdminAuth ? (
    <div key={product._id} className={classes.ProductInformation}>
        <img src={product.image} width="200" height="250" alt="Not available"/>
        <p>{product.productName}</p>
        <p>Description: {product.description}</p>
        <p>Price: {product.price}</p>
        <p>InStock: {product.inStock}</p>
        <p>{this.props.cart}</p>
        <button onClick={(productParameter,status)=>this.props.addCart(product,"add")}>Add to Cart (+)</button>
        <button onClick={(productId,status)=>this.props.addCart(product,"remove")}>Remove from Cart (-)</button>
        <button><Link to={'/UpdateProduct/'+product._id}>UpdateProduct</Link></button>
        <button><Link to={'/DeleteProduct/'+product._id}>DeleteProduct</Link></button>
    </div>
        ):
        (
        <div className={classes.ProductInformation}>
        <img src={product.image} width="200" height="250" alt="Not available"/>
        <p>{product.productName}</p>
        <p>Description: {product.description}</p>
        <p>Price: {product.price}</p>
        <p>InStock: {product.inStock}</p>
        <p>{this.props.cart}</p>
        <button onClick={(productParameter,status)=>this.props.addCart(product,"add")}>Add to Cart (+)</button><br/>
        <button onClick={(productId,status)=>this.props.addCart(product,"remove")}>Remove from Cart (-)</button>
    </div>)        
        )           
    return(
        <div className={classes.CategoriesItem}> 
            {products}
        </div>
    )
}
}

const mapStateToProps = state => {
    return {
        checkAdminAuth:state.loginReducer.admin,
        checkUserAuth:state.loginReducer.user
    }
}

export default connect(mapStateToProps,null)(CategoriesItem)