import React from 'react'
import classes from './Checkout.module.css'
import NavigatonItem from '../../components/NavigationBar/NavigationItem/NavigationItem'

const Checkout=props=>{
    let products=props.products.map(product=>(
            <div className={classes.productInformation}>
                <img src={product.image} width="200" height="250" alt={product.image}/>
                <p>{product.productName}</p>
            </div>
        ))
    return(
        <div className={classes.OuterCheckout}>
            <div className={classes.Checkout}> 
                {products}
            </div>
            <div className={classes.ProceedToBuyLink}>
                <NavigatonItem link="/shipping">Proceed to Buy</NavigatonItem>
            </div>
        </div>
    )
}


export default Checkout