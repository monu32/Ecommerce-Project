import React, { Component } from 'react';
import { connect } from 'react-redux';
import {Redirect} from 'react-router-dom'

import classes from './Shipping.module.css';
import Input from './../../UI/Input'
import axios from 'axios'
import * as actions from '../../store/actions/index'
import CategoriesItems from '../CategoriesItems/CategoriesItems';

class Shipping extends Component 
{
    state= 
    {
        orderForm:
        {
            name:{
                valid:false,
                value:'',
                fieldTouch:false
            },
            houseNo:{
                valid:false,
                value:'',
                fieldTouch:false
            },
            street:{
                valid:false,
                value:'',
                fieldTouch:false
            },
            landmark:{
                valid:false,
                value:'',
                fieldTouch:false
            },
            city:{
                valid:false,
                value:'',
                fieldTouch:false
            },
            state:{
                valid:false,
                value:'',
                fieldTouch:false
            },
            postalCode:{
                valid:false,
                value:0,
                fieldTouch:false
            },
            mobile:{
                valid:false,
                value:0,
                fieldTouch:false
            }
        },
        orderButtonStatus:false,
        checkFormSubmission:false
    }

    checkValidity=(value,inputElement)=>
    {
        let isValid=true
        switch(inputElement)
       {
            case('name'):
                return !(value==="")
            
            case('houseNo'):
                isValid=!(value==="")
                value=parseInt(value)
                return value>0 && isValid 

            case('street'):
                return !(value==="")
            
            case('landmark'):
                return !(value==="")

            case('city'):
               return !(value==="")

            case('state'):
               return !(value==="")
                
            case('mobile'):
                return value.length===10 && value.trim()!==''            
            
            case('postalCode'):
                return value.length===5 && value.trim()!==''
            default:
                return true
       }
    }

    checkFormValidation=(updatedOrderForm)=>
    {
        let productValidation=true
        const productInformation={...updatedOrderForm}
        for(let inputField in productInformation)
            productValidation=productValidation && productInformation[inputField].valid
        this.setState({orderForm:updatedOrderForm,orderButtonStatus:productValidation})
    }

    inputChangedHandler=(event)=>
    {   
        const IsValid=this.checkValidity(event.target.value,event.target.name)
        const updatedElement={...this.state.orderForm[event.target.name]}
        updatedElement.valid=IsValid
        updatedElement.value=event.target.value
        updatedElement.fieldTouch=true

        let updatedOrderForm={...this.state.orderForm}
        updatedOrderForm[event.target.name]=updatedElement

        this.checkFormValidation(updatedOrderForm)
    }

    orderHandler=(event)=>
    {
        event.preventDefault()
        this.setState({checkFormSubmission:true})
        const userInformation=
        {
            userName:this.state.orderForm.name.value,
            mobile:this.state.orderForm.mobile.value,
            address:
            {
                houseNo:this.state.orderForm.houseNo.value,
                street:this.state.orderForm.street.value,
                landmark:this.state.orderForm.landmark.value,
                city:this.state.orderForm.city.value,
                state:this.state.orderForm.state.value,
                postalCode:this.state.orderForm.postalCode.value
            }
        }
        axios.patch('/api/user/updateUser',userInformation)
        .then(res=>{
        })
        .catch(error=>{
        })            
        const cart={...this.props.cart}
        this.props.EmptyCart()
        for(let index in cart)
            this.props.updateOrdersList(cart[index])
    }

    render () {
        let form = (
            <form>
                <Input InputType="input" type="text" name="name" placeholder="Your Name" valid={this.state.orderForm.name.valid} fieldTouch={this.state.orderForm.name.fieldTouch} changed={(event)=>this.inputChangedHandler(event)}/>
                <Input InputType="input" type="number" name="houseNo" placeholder="House No" valid={this.state.orderForm.houseNo.valid} fieldTouch={this.state.orderForm.houseNo.fieldTouch} changed={(event)=>this.inputChangedHandler(event)}/>
                <Input InputType="input" type="text" name="street" placeholder="Street" valid={this.state.orderForm.street.valid} fieldTouch={this.state.orderForm.street.fieldTouch} changed={(event)=>this.inputChangedHandler(event)}/>
                <Input InputType="input" type="text" name="landmark" placeholder="Landmark" valid={this.state.orderForm.landmark.valid} fieldTouch={this.state.orderForm.landmark.fieldTouch} changed={(event)=>this.inputChangedHandler(event)}/>                
                <Input InputType="input" type="text" name="city" placeholder="City" valid={this.state.orderForm.city.valid} fieldTouch={this.state.orderForm.city.fieldTouch} changed={(event)=>this.inputChangedHandler(event)}/>
                <Input InputType="input" type="text" name="state" placeholder="State" valid={this.state.orderForm.state.valid} fieldTouch={this.state.orderForm.state.fieldTouch} changed={(event)=>this.inputChangedHandler(event)}/>
                <Input InputType="input" type="number" name="postalCode" placeholder="Postal Code(5 digit)" valid={this.state.orderForm.postalCode.valid} fieldTouch={this.state.orderForm.postalCode.fieldTouch} changed={(event)=>this.inputChangedHandler(event)}/>
                <Input InputType="input" type="number" name="mobile" placeholder="Mobile" valid={this.state.orderForm.mobile.valid} fieldTouch={this.state.orderForm.mobile.fieldTouch} changed={(event)=>this.inputChangedHandler(event)}/>
                <button disabled={!this.state.orderButtonStatus} onClick={this.orderHandler}>ORDER</button>
            </form>
        )
        let redirectPath=null
        if(this.state.checkFormSubmission)
            redirectPath=<Redirect to="/"/>
    
        let formData=form
        if(!this.props.checkUserAuth && !this.props.checkAdminAuth)    
        {
            formData=null
            redirectPath=<Redirect to="/"/>
            alert("Please Login")
        }

        return (
            <div className={classes.ShippingInformation}>  
                <p>Please Fill the details</p>
                    {formData}
                    {redirectPath}
            </div>
        );
    }
}

const mapStateToProps=state=>{
    return {
        cart:state.cartReducer.Cart,
        checkUserAuth:state.loginReducer.user,
        checkAdminAuth:state.loginReducer.admin,
    }
}

const mapDispatchToProps=dispatch=> 
{
    return {
        updateOrdersList:(quantity,id,image)=>dispatch(actions.updateOrdersList(quantity,id,image)),
        EmptyCart:()=>dispatch(actions.EmptyCart())
    }
}

export default connect(mapStateToProps,mapDispatchToProps)(Shipping)