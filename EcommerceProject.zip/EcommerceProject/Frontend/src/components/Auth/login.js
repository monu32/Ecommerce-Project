import React,{Component} from 'react'

class login extends Component
{
    componentDidMount()
    {
            window.location.replace("http://localhost:3000/auth/google");
    }

    render()
    {
        return(
            <div>
            </div>
        )    
    }
}

export default login
