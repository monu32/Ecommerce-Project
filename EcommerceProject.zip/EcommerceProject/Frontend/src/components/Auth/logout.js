import React,{Component} from 'react'
import axios from 'axios'

class logout extends Component
{
    componentDidMount()
    {
        axios.get('/api/user/logoutUser')
        .then(res=>{
            console.log(res)
        })
        .catch(error=>{
            console.log("Error")
        })
        this.props.history.goBack()
        window.location.replace("http://localhost:3006/");
    }

    render()
    {
        return(
            <div>
            </div>
        )    
    }
}

export default logout

