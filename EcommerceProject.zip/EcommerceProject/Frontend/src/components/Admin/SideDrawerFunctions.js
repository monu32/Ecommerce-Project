import React,{Component} from 'react'
import { connect } from 'react-redux';

import classes from './SideDrawerFunctions.module.css'
import NavigationItem from '../NavigationBar/NavigationItem/NavigationItem'

class SideDrawerFunctions extends Component
{
    state={
        categories:["Add New Product","Orders"]
    }
    render(){
        let userFunctions=null
        if(this.props.checkAdminAuth)
        {
            userFunctions=(
                <div className={classes.SideDrawerFunctions}>
                    {this.state.categories.map(category=>(
                        <NavigationItem key={category} link={category}>{category}</NavigationItem> 
                    ))}
                </div>    
            )
        }
        else if(this.props.checkUserAuth)
        {
            userFunctions=(
                <div className={classes.AdminFunctions}>
                    {this.state.categories.map(category=>category!=="Add New Product"?(
                        <NavigationItem key={category} link={category}>{category}</NavigationItem> 
                    ):null)}
                </div>    
            )
        }

        return(
            <div>
                {userFunctions}
            </div>
        )
    }
}

const mapStateToProps = state => {
    return {
        checkAdminAuth:state.loginReducer.admin,
        checkUserAuth:state.loginReducer.user
    }
}

export default connect(mapStateToProps,null)(SideDrawerFunctions)