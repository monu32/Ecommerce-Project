import React,{Component} from 'react'
import Input from '../../../UI/Input'
import classes from './AddNewProduct.module.css'
import axios from 'axios'
import {Redirect} from 'react-router-dom'
import { connect } from 'react-redux'

class addNewProduct extends Component
{
    state= 
    {
        productForm:{
            productName:{
                valid:false,
                value:'',
                fieldTouch:false
            },
            image:{
                valid:false,
                value:"",
                fieldTouch:false
            },
            description:{
                valid:false,
                value:'',
                fieldTouch:false
            },
            inStock:{
                valid:true,
                value:true,
                fieldTouch:false
            },
            price:{
                valid:false,
                value:0,
                fieldTouch:false
            },
            quantity:{
                valid:false,
                value:0,
                fieldTouch:false
            },
            category:{
                valid:false,
                value:'',
                fieldTouch:false
            },    
        },
        productButtonStatus:false,
        productStatus:false,
        store:false
    }

    checkFormValidation=(updatedProductForm)=>
    {
        let productValidation=true
        const productInformation={...updatedProductForm}
        for(let inputField in productInformation)
            productValidation=productValidation && productInformation[inputField].valid
        this.setState({productForm:updatedProductForm,productButtonStatus:productValidation})
    }

    inputChangedHandler=(event)=>
    {   
        const IsValid=this.checkValidity(event.target.value,event.target.name)
        const updatedElement={...this.state.productForm[event.target.name]}
        updatedElement.valid=IsValid
        updatedElement.value=event.target.value
        updatedElement.fieldTouch=true

        let updatedProductForm={...this.state.productForm}
        updatedProductForm[event.target.name]=updatedElement

        this.checkFormValidation(updatedProductForm)
    }

    imageHandler=(event)=>
    {
        if(!event.target.files[0])
            return
        const updatedElement={...this.state.productForm["image"]}
        updatedElement.valid=true

        updatedElement.fieldTouch=true
        let updatedProductForm={...this.state.productForm}
        

        const self=this
        var file = event.target.files[0];
        var reader = new FileReader();
        reader.onloadend = function() {
          self.setState({storeImage:reader.result})
          updatedElement.value=reader.result
        }
        reader.readAsDataURL(file);
        updatedProductForm["image"]=updatedElement

        this.checkFormValidation(updatedProductForm)
    }
    productHandler=(event)=>
    {
        event.preventDefault()
        const productInformation=
        {
            productName:this.state.productForm.productName.value,
            description:this.state.productForm.description.value,
            price:this.state.productForm.price.value,
            quantity:this.state.productForm.quantity.value,
            inStock:this.state.productForm.inStock.value,
            category:this.state.productForm.category.value,
            image:this.state.productForm.image.value
        }
        this.setState({store:true})
        axios.post("/api/product/newProduct",productInformation)
        .then(res=>{
            console.log(res)
            console.log("product added")
            alert("PRODUCT ADDED SUCCESSFULLY")
        })
        .catch(error =>{
            alert("There is some error in add new product,plese try after some time...")
        })
        window.location.replace("http://localhost:3006/")
    }

    checkValidity=(value,inputElement)=>
    {
        let isValid=true
        switch(inputElement)
       {
            case('productName'):
                return !(value==="")

            case('description'):
                return !(value==="")

            case('price'):
                isValid=!(value==="")
                value=parseInt(value)
                return value>0 && isValid           

                case('quantity'):
                isValid=!(value==="")
                value=parseInt(value)
                return value>0 && isValid
            
            case('category'):
                return !(value==="")
            default:
                return true
       }
    }

    render()
    {
    let form=(
        <form>
        <Input InputType="input" type="text" name="productName" placeholder="Product Name" valid={this.state.productForm.productName.valid} fieldTouch={this.state.productForm.productName.fieldTouch} changed={(event)=>this.inputChangedHandler(event)}/>
        <Input InputType="textarea" type="text" name="description" placeholder="Description" valid={this.state.productForm.description.valid} fieldTouch={this.state.productForm.description.fieldTouch} changed={(event)=>this.inputChangedHandler(event)}/>
        <Input InputType="input" type="number" name="price" placeholder="Price" valid={this.state.productForm.price.valid} fieldTouch={this.state.productForm.price.fieldTouch} changed={(event)=>this.inputChangedHandler(event)}/>
        <Input InputType="input" type="number" name="quantity" placeholder="Quantity" valid={this.state.productForm.quantity.valid} fieldTouch={this.state.productForm.quantity.fieldTouch} changed={(event)=>this.inputChangedHandler(event)}/>
        <Input InputType="input" type="text" name="category" placeholder="Category" valid={this.state.productForm.category.valid} fieldTouch={this.state.productForm.category.fieldTouch} changed={(event)=>this.inputChangedHandler(event)}/>
        <Input InputType="file" type="file" name="image" valid={this.state.productForm.image.valid} fieldTouch={this.state.productForm.image.fieldTouch} changed={(event)=>this.imageHandler(event)}/>
        <Input InputType="select" type="select" name="inStock" valid={this.state.productForm.category.valid} fieldTouch={this.state.productForm.category.fieldTouch} changed={(event)=>this.inputChangedHandler(event)}/>
        <button disabled={!this.state.productButtonStatus} onClick={this.productHandler}>ADD PRODUCT</button>
    </form>)

    let redirectPath=null
    if(this.state.store)
        redirectPath=<Redirect to="/"/>

    let formData=form
    if(!this.props.checkAdminAuth)
        {
        formData=null
        redirectPath=<Redirect to="/"/>
        alert("Please Login")
        }   
    
    return(
            <div className={classes.AddNewProduct}>
            <h4>Add New Product</h4>
                {formData}
                {redirectPath}
           </div>
    )
    }
}

const mapStateToProps = state => {
    return {
        checkAdminAuth:state.loginReducer.admin,
    }
}


export default connect(mapStateToProps,null)(addNewProduct)

