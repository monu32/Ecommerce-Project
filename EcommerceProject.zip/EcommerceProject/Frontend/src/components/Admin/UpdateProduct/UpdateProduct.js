import React,{Component} from 'react'
import {connect} from 'react-redux'

import Input from '../../../UI/Input'
import classes from './UpdateProduct.module.css'
import axios from 'axios'
import {Redirect} from 'react-router-dom'

class updateProduct extends Component
{
    state= 
    {
        productForm:{
            productName:{
                valid:true,
                value:'',
                fieldTouch:false
            },
            image:{
                valid:true,
                value:'',
                fieldTouch:false
            },
            description:{
                valid:true,
                value:'',
                fieldTouch:false
            },
            inStock:{
                valid:true,
                value:true,
                fieldTouch:false
            },
            price:{
                valid:true,
                value:'',
                fieldTouch:false
            },
            quantity:{
                valid:true,
                value:'',
                fieldTouch:false
            },
            category:{
                valid:true,
                value:'',
                fieldTouch:false
            },    
        },
        productButtonStatus:true,
        store:false
    }

    checkFormValidation=(updatedProductForm)=>
    {
        let productValidation=true
        const productInformation={...updatedProductForm}
        for(let inputField in productInformation)
            productValidation=productValidation && productInformation[inputField].valid
        this.setState({productForm:updatedProductForm,productButtonStatus:productValidation})
    }

    inputChangedHandler=(event)=>
    {   
        const IsValid=this.checkValidity(event.target.value,event.target.name)
        const updatedElement={...this.state.productForm[event.target.name]}
        updatedElement.valid=IsValid
        updatedElement.value=event.target.value
        updatedElement.fieldTouch=true

        let updatedProductForm={...this.state.productForm}
        updatedProductForm[event.target.name]=updatedElement

        this.checkFormValidation(updatedProductForm)
    }

    imageHandler=(event)=>
    {
        if(!event.target.files[0])
            return
        const updatedElement={...this.state.productForm["image"]}
        updatedElement.valid=true

        updatedElement.fieldTouch=true
        let updatedProductForm={...this.state.productForm}
        

        const self=this
        var file = event.target.files[0];
        var reader = new FileReader();
        reader.onloadend = function() {
          self.setState({storeImage:reader.result})
          updatedElement.value=reader.result
        }
        reader.readAsDataURL(file);
        updatedProductForm["image"]=updatedElement

        this.checkFormValidation(updatedProductForm)
    }
    productHandler=(event)=>
    {
        this.setState({store:true})
        event.preventDefault()
        let productInformation={}
        for(let field in this.state.productForm)
        {
            console.log(this.state.productForm[field].value)
           if(!(this.state.productForm[field].value==='') && field!=='inStock')
            {
                console.log(this.state.productForm[field].value)
                const object={[field]:this.state.productForm[field].value}
                productInformation=Object.assign(productInformation,object)
            }    
        }
        const _id=this.props.match.params.id
        axios.patch('/api/product/updateProduct/'+_id,productInformation)
        .then(res=>{
            alert("PRODUCT UPDATED SUCCESSFULLY")
        })
        .catch(error =>{
            alert("There might be some Error,Please try after some time...")
        })  
        window.location.replace("http://localhost:3006/")
    }

    checkValidity=(value,inputElement)=>
    {
        switch(inputElement)
       {
            case('price'):
                if(!(value===""))
                {
                    value=parseInt(value)
                    return value>0    
                }
                return true

            case('quantity'):
            if(!(value===""))
            {
                value=parseInt(value)
                return value>0    
            }
            return true
        
            default:
                return true
       }
    }

    render()
    {
    let form=(
        <form>
        <Input InputType="input" type="text" name="productName" placeholder="Product Name" valid={this.state.productForm.productName.valid} fieldTouch={this.state.productForm.productName.fieldTouch} changed={(event)=>this.inputChangedHandler(event)}/>
        <Input InputType="textarea" type="text" name="description" placeholder="Description" valid={this.state.productForm.description.valid} fieldTouch={this.state.productForm.description.fieldTouch} changed={(event)=>this.inputChangedHandler(event)}/>
        <Input InputType="input" type="number" name="price" placeholder="Price" valid={this.state.productForm.price.valid} fieldTouch={this.state.productForm.price.fieldTouch} changed={(event)=>this.inputChangedHandler(event)}/>
        <Input InputType="input" type="number" name="quantity" placeholder="Quantity" valid={this.state.productForm.quantity.valid} fieldTouch={this.state.productForm.quantity.fieldTouch} changed={(event)=>this.inputChangedHandler(event)}/>
        <Input InputType="input" type="text" name="category" placeholder="Category" valid={this.state.productForm.category.valid} fieldTouch={this.state.productForm.category.fieldTouch} changed={(event)=>this.inputChangedHandler(event)}/>
        <Input InputType="file" type="file" name="image" valid={this.state.productForm.image.valid} fieldTouch={this.state.productForm.image.fieldTouch} changed={(event)=>this.imageHandler(event)}/>
        <Input InputType="select" type="select" name="inStock" valid={this.state.productForm.category.valid} fieldTouch={this.state.productForm.category.fieldTouch} changed={(event)=>this.inputChangedHandler(event)}/>
        <button disabled={!this.state.productButtonStatus} onClick={this.productHandler}>UPDATE PRODUCT</button>
    </form>)

    let redirectPath=null
    if(this.state.store)
        redirectPath=<Redirect to="/"/>
    
    let formData=form
    if(!this.props.checkAdminAuth)
     {
        formData=null
        redirectPath=<Redirect to="/"/>
        alert("Please Login")
     }   
    
    return(
            <div className={classes.UpdateProduct}>
            <p>UPDATE PRODUCT</p>
                {formData}
                {redirectPath}
           </div>
    )
    }
}

const mapStateToProps = state => {
    return {
        checkAdminAuth:state.loginReducer.admin,
    }
}


export default connect(mapStateToProps,null)(updateProduct)

