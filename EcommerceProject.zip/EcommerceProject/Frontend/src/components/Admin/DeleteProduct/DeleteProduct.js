import React from 'react'
import {Redirect} from 'react-router-dom' 
import axios from 'axios'

const deleteProduct=props=>
{
        const _id=props.match.params.id
        axios.delete('/api/product/deleteProduct/'+_id)
        .then(res=>{
            alert("PRODUCT DELETED SUCCESSFULLY")
        })
        .catch(error=>{
            alert("There might be some Error,Please try after some time...")
        })

        window.location.replace("http://localhost:3006/")
        return(
            <div>
                <Redirect to="/" exact/>
            </div>
        )
}

export default deleteProduct