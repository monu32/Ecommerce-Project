import React, { Component } from 'react'
import classes from './OrdersList.module.css'
import { connect } from 'react-redux';

class OrdersList extends Component
{
    render()
    {
        let products=this.props.Orders.map(product=>(
            <div className={classes.productInformation}>
                <img src={product.image}width="200" height="250" alt={product.image}/>
                <p>{product.productName}</p>
                <p>Order Data : {product.orderDate.substring(0,10)}</p>
            </div>
        ))

        return(
            <div className={classes.OrdersList}> 
                {products}
            </div>
        )
    }
}

const mapStateToProps = state => {
    return {
        Orders:state.ordersReducer.Orders
    }
}
export default connect(mapStateToProps,null)(OrdersList)