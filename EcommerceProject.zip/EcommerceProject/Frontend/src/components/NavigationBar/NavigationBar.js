import React,{Component} from 'react'
import {connect} from 'react-redux'

import NavigationItem from './NavigationItem/NavigationItem'
import classes from './NavigationBar.module.css'
import cartImage from '../../assets/images/cart.png'

class navigationItems extends Component
{
    render()
    {
        return(
            <ul className={classes.NavigationBar}>
            {(!this.props.checkUserAuth && !this.props.checkAdminAuth)?<NavigationItem link="/login">Login</NavigationItem> :
            <NavigationItem link="/logout">Logout</NavigationItem>}
            <NavigationItem link="/cart"><img src={cartImage} alt="Cart"/></NavigationItem>
        </ul>   
        )
    }
}

const mapStateToProps = state => {
    return {
        checkAdminAuth:state.loginReducer.admin,
        checkUserAuth:state.loginReducer.user
    }
}

export default connect(mapStateToProps,null)(navigationItems)