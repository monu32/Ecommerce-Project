import React,{Component} from 'react'
import classes from './NavigationItem.module.css'
import {connect} from 'react-redux'

import {Link} from 'react-router-dom'

class navigationItem extends Component
{    render()
    {
    const link=this.props.link.replace(/\s/g,'')
    let checkAuth=(
        <Link
        to={link}
        className={this.props.active?classes.active:null}
        >{this.props.children}
        </Link> 
    )
    return(
        <div>
            <li className={classes.NavigationItem}>
                {checkAuth}
            </li>
        </div>
    )
    }
}

const mapStateToProps = state => {
    return {
        checkAdminAuth:state.loginReducer.admin,
        checkUserAuth:state.loginReducer.user
    }
}

export default connect(mapStateToProps,null)(navigationItem)