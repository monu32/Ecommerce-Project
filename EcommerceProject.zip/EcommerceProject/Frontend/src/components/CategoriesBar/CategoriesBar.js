import React,{Component} from 'react'
import classes from './CategoriesBar.module.css'
import CategoriesNavigationItem from './CategoriesNavigationItem/CategoriesNavigationItem'

class CategoriesBar extends Component{
    render()
    {
        let attachedClass=[classes.CategoriesBar,classes.DesktopOnly]
        return (
                <div className={attachedClass.join(' ')}>
                    <CategoriesNavigationItem/>
                </div>
        )
    }
}

export default CategoriesBar