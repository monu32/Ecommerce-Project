import React,{Component} from 'react'
import classes from './CategoriesNavigationItem.module.css'
import NavigationItem from '../../NavigationBar/NavigationItem/NavigationItem'
import { connect } from 'react-redux';

class CategoriesNavigationItem extends Component
{
    render(){
        return(
            <div className={classes.CategoriesItem}>
                {this.props.Categories.map(category=>(
                    <NavigationItem key={category} link={category}>{category}</NavigationItem> 
                ))}
            </div>
        )
    }
}

const mapStateToProps = state => {
    return {
        Categories:state.productReducer.Categories
    }
}

export default connect(mapStateToProps,null)(CategoriesNavigationItem)