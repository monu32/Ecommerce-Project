import React,{Component} from 'react'
import { connect } from 'react-redux';
import classes from './Home.module.css'
// Must set id in key to remove the duplication

class homePage extends Component
{
render()
{
    let products=null
    if(this.props.products)
    {
        products=this.props.products
        let FilteredProduct=products
        const Categories=this.props.Categories
        let uniqueProducts=[]
        for(let categoryIndex in Categories)
        {
            for(let productIndex in FilteredProduct)
            {
                const category=Categories[categoryIndex]
                 if(FilteredProduct[productIndex][category]!==undefined && FilteredProduct[productIndex][category][0]!==undefined)
                     uniqueProducts.push(FilteredProduct[productIndex][category][0])
            }
        }
        products=uniqueProducts.map(product=>(
        <div key={product._id} className={classes.ProductInformation}>
            <img src={product.image} width="200" height="250" alt="not available"/>
            <p>{product.productName}</p>
            <p>Description: {product.description}</p>
            <p>Price: {product.price}</p>
        </div>))           
    
    }
    return(
        <div className={classes.CategoriesItem}> 
            {products}
        </div>
    )
}
}

const mapStateToProps = state => {
    return {
        Categories:state.productReducer.Categories,
        products:state.productReducer.Products
    }
}

export default connect(mapStateToProps,null)(homePage)