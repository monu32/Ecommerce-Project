import React from 'react'
import classes from './Toolbar.module.css'
import NavigationBar from '../NavigationBar/NavigationBar'
import Logo from '../Logo/Logo'
import DrawerToggleButton from '../SideDrawer/DrawerToggleButton/DrawerToogleButton'

const toolbaar=props=>(
    <div>
        <header className={classes.Toolbar}>
            <DrawerToggleButton clicked={props.DrawerToggleButtonClicked}/>
            <Logo height="80%"/>
            <nav className={classes.DesktopOnly}>
                <NavigationBar/>
            </nav>
        </header>
    </div>
)

export default toolbaar