import React,{Component} from 'react'
import Toolbar from '../../components/Toolbar/Toolbar'
import SideDrawer from '../../components/SideDrawer/SideDrawer'
import classes from './Layout.module.css'
import CategoriesBar from '../../components/CategoriesBar/CategoriesBar'

class Layout extends Component{
    state=
    {
        showSideDrawer:false
    }

    sideDrawerClosedHandler=()=>
    {
        this.setState({showSideDrawer:false})
    }

    sideDrawerToggleHandler=()=>
    {
        this.setState(prevState=>
            {
            return {showSideDrawer:!prevState.showSideDrawer}
            })
    }
    render()
    {
        return (
            <div>
                <div className={classes.Content}>
                    <Toolbar DrawerToggleButtonClicked={this.sideDrawerToggleHandler}/>
                    <SideDrawer
                    open={this.state.showSideDrawer}  
                    closed={this.sideDrawerClosedHandler}/>
                </div>
                <div className={classes.Content}>
                    <CategoriesBar/>
                </div>
            </div>
              )
    }
}

export default Layout