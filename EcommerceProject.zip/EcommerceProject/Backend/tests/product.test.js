//Import modules
const request = require('supertest')
const app = require('../src/app')
const jwt=require('jsonwebtoken')
const mongoose=require('mongoose')
const User=require('../src/models/product')

//Create instance of product
const product={
    _id:new mongoose.Types.ObjectId(),
    productName:"Shoes",
    description:"Comfortable shoes",
    inStock:true,
    category:"Sports",
    quantity:3,
    price:3000.50
}

//test cases begins here

test('Should Add new product', async () => {
    await User.deleteMany()
    await request(app).post('/api/product/newProduct').send({
        _id:product._id,
        productName:product.productName,
        description:product.description,
        inStock:product.inStock,
        category:product.category,
        quantity:product.quantity,
        price:product.price
    }).expect(201)
})

test('Should get all products',async()=>{
    await request(app).get('/api/product/getProducts')
    .send()
    .expect(200)
})

test('Should not get product', async () => {
    await request(app).post('/api/product/getProduct/')
    .send()
    .expect(404)
})

test('Should not get image', async () => {
    await request(app).post('/api/product/getProductImage').send({
    }).expect(404)
})

