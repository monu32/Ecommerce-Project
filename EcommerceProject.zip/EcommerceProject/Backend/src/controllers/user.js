//Import require modules
const User=require('../models/user')
const Product=require('../models/product')
const sharp=require('sharp')
const jwt=require('jsonwebtoken')

//Login user
exports.loginUser=(req,res)=>{
    res.send("Login succssfully...Use postman for rest of the endpoints")
}

// Create new user
exports.createUser=async (req,res)=>{
    try
    {
     const user=new User(req.body)
     await user.save()
     res.send(user)
    }
    catch(error)
     {
         res.status(500).send(error)
     }
}

//Get profile of user
exports.getUser=async (req,res)=>{
    res.status(200).send(req.user)
}

//Update user
exports.updateUser=async (req,res)=>{
    try
    {
       const googleId=localStorage.getItem('loginUser')
       const user=await User.findOneAndUpdate({googleId},req.body,{new:true,runValidators:true})
       if(!user)
        return res.status(404).send()      
       await user.save()
       res.send(user)
    }
    catch(error)
     {
        res.status(500).send(error)
     }
}    

//Get all available products
exports.getAllProducts=async(req,res)=>
{
    try
    {
      const product=await Product.find({})
      res.status(200).send(product)
    }
    catch(error)
    {
      res.status(500).send()
    }  
}


// Update orders list (purchase new product)
exports.updateOrdersList=async (req,res)=>{
    try
    {   
     const googleId=localStorage.getItem('loginUser')
     if(!req.params.productId || !req.params.quantity)
      return res.status(400).send("Product not found")
     const product=await Product.findById(req.params.productId)
     if(!product)
      return res.status(404).send("Product not found")
     if(product.InStock==false || !product.quantity)
      return res.status(200).send("Product is not available")     
     const user=await User.findOne({googleId})
     if(!user)
      return res.status(404).send()
    
     product.quantity=product.quantity-req.params.quantity  
     if(product.quantity<0)
      product.quantity=0
     
     const orderInformation={ 
        orderDate:new Date(),
        image:req.body.image,
        quantity:req.params.quantity,
        productId:req.params.productId,
        status:"Dispatched"
     }
     user.orders.push(orderInformation)
     await user.save() 
     await product.save() 
     
     res.status(200).send(user) 
    }
    catch(error)
    {
     res.status(500).send(error)    
    }
}

//Get all orders from list
exports.getAllOrders=async (req,res)=>{
    try
    {
     const googleId=localStorage.getItem('loginUser')
     const product=await User.find({googleId},{userName:true,orders:true})
     if(!product)
      return res.status(404).send()
     res.status(200).send(product[0].orders)
    }
    catch(error)
     {
         res.status(500).send(error)
     }
}

exports.updateCart=async (req,res)=>{    
    try
    {   
    const googleId=localStorage.getItem('loginUser')
    let user=await User.findOne({googleId})
    if(!user)
        return res.status(404).send()

    const checkProduct=await User.findOne({googleId:googleId,"cart.productId":req.body.productId},{cart:true})
    if(!checkProduct)
    {
        if(req.params.id=="remove") 
            res.status("200")
        else
        {
            req.body.quantity=1
            user.cart.push(req.body)
            await user.save()
        }
        res.status(200).send(user.cart) 
    }
    else 
    {
        const data=checkProduct.cart
        for(let index in data)
        {
            if(data[index].productId==req.body.productId)
            {
            if(req.params.id=="remove")
                data[index].quantity=data[index].quantity-1 
            else
                data[index].quantity=data[index].quantity+1
            break
            }
        }
        checkProduct.cart=data.filter(item=>item.quantity!=0)

        await checkProduct.save()
        res.status(200).send(checkProduct.cart) 
    }
    }
    catch(error)
    {
     res.status(500).send(error)    
    }
}

//Get Cart Items
exports.getCartItems=async (req,res)=>{
    try
    {
     const googleId=localStorage.getItem('loginUser')
     const products=await User.find({googleId},{cart:true})
     if(!products)
      return res.status(404).send()
     res.status(200).send(products[0].cart)
    }
    catch(error)
     {
         res.status(500).send(error)
     }
}

//Remove cart items
exports.removeCartItem=async(req,res)=>{
    try
    {
     const googleId=localStorage.getItem('loginUser') 
     const user=await User.findOne({googleId})
     if(!user)
      return res.status(404).send()
     user.cart=[]
     await user.save()
     res.status(200).send() 
    }
    catch(error)
    {
     res.status(500).send(error)         
    }

}

//Delete user
exports.deleteUser=async (req,res)=>{
    try
    {
     const googleId=localStorage.getItem('loginUser') 
     const user=await User.findOneAndDelete({googleId})
     if(!user)
      return res.status(404).send()
     localStorage.removeItem('loginUser')
     localStorage.removeItem('token')
     if(localStorage.getItem('admin'))
        localStorage.removeItem('admin')

     req.logout()
     res.status(200).send(user)
    }
    catch(error)
    {
     res.status(500).send(error)         
    }
}

// Logout user
exports.logoutUser=async (req,res)=>
{
        try
        { 
            const googleId=localStorage.getItem('loginUser')
            if(!googleId)
                return res.status(200).send()
        
            const user=await User.findOne({googleId})
            if(!user)
                return res.status(200).send()
            localStorage.removeItem('loginUser')
            localStorage.removeItem('token')

            if(localStorage.getItem('admin'))
                localStorage.removeItem('admin')
            await user.save()
            req.logout()     
            res.send('LOGOUT SUCCESSFULLY')    
            }
        catch(error)
        {
            res.status(500).send(error)
        }
}
