//Import modules
const passport=require('passport')
const GoogleStrategy=require('passport-google-oauth2').Strategy
const keys=require('../../config/keys')
const User=require('../models/user')
const fs = require('fs'); 

//113867898748915296439
passport.serializeUser((user,done)=>{
    done(null,user.id)
})

passport.deserializeUser((id,done)=>{
    User.findById(id).then(user=>done(null,user.id)).catch(error=>console.log(error))
})

passport.use(
    new GoogleStrategy({
        clientID:keys.googleClientId,
        clientSecret:keys.googleClientSecret,
        callbackURL:"/auth/google/callback"
    },
    (request,accessToken,refreshToken,profile,done)=>{
        User.findOne({googleId:profile.id}).then((currentUser)=>{
            if(currentUser)                                        //If user is already singup  
                {
                    localStorage.setItem('loginUser',profile.id)   // Save googleId of current login user
                    const user=User.findOne({googleId:profile.id})
                    user.then(user=>{
                        if(profile.email=="monuecommerce@gmail.com")
                            {localStorage.setItem('admin',true)
                    }
                        user.generateAuthToken()            //Generate token
                    }).catch(error=>console.log(error))
                    done(null,currentUser)
                }
            else 
            {
                localStorage.setItem('loginUser',profile.id)
                new User({                                  //New user
                    userName:profile.displayName,
                    googleId:profile.id,
                    email:profile.email
                }).save().then(newUser=>{
                    const user=User.findOne({googleId:profile.id})
                    user.then(user=>user.generateAuthToken()).catch(error=>console.log(error))
                    done(null,newUser)
                }).catch(error=>console.log(error))        
            }
        }).catch(error=>console.log(error))
    })
)
