// import Require Modules
const express=require('express')
const router=new express.Router()
const productController=require('../controllers/product')
const multer=require('multer')
const auth=require('../middleware/productAuth')

//get all products
router.get('/api/product/getProducts',productController.getProducts)

//get single product by id
router.get('/api/product/getProduct/:id',auth,productController.getProduct)

// Enter new product in database
router.post('/api/product/newProduct',auth,productController.newProduct) 

// update product by id
router.patch('/api/product/updateProduct/:id',auth,productController.updateProduct) 

// delete product by id
router.delete('/api/product/deleteProduct/:id',auth,productController.deleteProduct) 

module.exports=router
