// import Require Modules
const express=require('express')
const router=new express.Router()
const userController=require('../controllers/user')
const multer=require('multer')
const auth=require('../middleware/userAuth')

//login user
router.get('/api/user/loginUser/',userController.loginUser)

//create new user
router.post('/api/user/createUser',userController.createUser)


//get user
router.get('/api/user/getUser/',auth,userController.getUser)

//Update user
router.patch('/api/user/updateUser',auth,userController.updateUser)

//Get all available products
router.get('/api/user/getAllProducts',userController.getAllProducts)

//Update orders list (Purchase new item)
router.patch('/api/user/updateOrdersList/:productId/:quantity',auth,userController.updateOrdersList)

//Get all orders
router.get('/api/user/getAllOrders',auth,userController.getAllOrders)

//Delete user
router.delete('/api/user/deleteUser',auth,userController.deleteUser)

//Get Cart Items
router.get('/api/user/getCartItems',auth,userController.getCartItems)

//Add Cart
router.post('/api/user/updateCart/:id',auth,userController.updateCart)

//Remove cart items
router.patch('/api/user/removeCartItem',auth,userController.removeCartItem)

//Logout User
router.get('/api/user/logoutUser',auth,userController.logoutUser)

module.exports=router