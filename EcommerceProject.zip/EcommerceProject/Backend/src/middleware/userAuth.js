//Import modules
const jwt=require('jsonwebtoken')
const User=require('../models/user')

//Create authentication middleware
const auth=async(req,res,next)=>
{
    try
    {
        const token=localStorage.getItem('token')
        const decoded=jwt.verify(token,process.env.JWT_SECRET)
        const user=await User.findOne({googleId:decoded._id})
        if(!user)
            throw new Error()         
        req.user=user
        next()    
    } 
   catch(error)
    {
        res.status(401).send("Invalid authentication")
    } 
}

module.exports=auth