//Import Require Modules
const mongoose = require('mongoose')
const validator = require('validator')

//Create Schema of Product
const productSchema=new mongoose.Schema({
    productName: 
    {
        type:String,
        required:true,
        trim:true
    },
    image:
    {
        type:String,
        required:true
    },
    description:
    {
        type:String,
        trim:true
    },
    inStock:
    {
        type:Boolean,
        required:true
    },
    price:
    {
        type:Number,
        required:true,
        validate(value)
         {  
            if(value<0)
             throw new Error("Price is ")
         }
    },
    quantity:
    {
        type:Number,
        required:true,
        validate(value)
         {
             if(value<0)
              throw new Error("Quantity is INVALID")
         }
    },
    category:
    {
        type:String,
        required:true
    }

},{timestamps:true})

const Product = mongoose.model('Product',productSchema)

module.exports = Product
