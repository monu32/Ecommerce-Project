//Import Require Modules
const mongoose = require('mongoose')
const validator = require('validator')
const jwt=require('jsonwebtoken')

//Create Schema of User
const userSchema=new mongoose.Schema({
    userName: 
    {
        type:String,
        required:true,
        trim:true
    },
    googleId:
    {
        type:String,
        required:true
    },
    mobile:
    {
        type:Number,
        validate(value) 
        {
            if((value.length===10)===true)
                throw new Error('Mobile number is INVALID')
        }
    },
    email:
    {
        type:String,
        unique:true,
        required:true,
        validate(value)
        {
            if(!validator.isEmail(value))
              throw new Error("Email is INVALID")
        }
    },
    address:
    {
     houseNo:
      {
          type:Number,
          validate(value)
          {
              if(value<0)
                throw new Error("House Number INVALID")
          }
      },
      street:
      {
          type:String,
          trim:true
      },
      landmark:
      {
          type:String,
          trim:true
      },
      city:
      {
          type:String,
          trim:true
      },
      state:
      {
          type:String,
          trim:true
      },
      postalCode:
      {
          type:Number
      }
    },
    cart:[{
        productId:
        {
            type:String,
            required:true
        },
        productName:
        {
            type:String,
            required:true
        },
        image:
        {
            type:String
        },
        quantity:
        {
            type:Number,
            required:true,
            validate(value)
             {
                 if(value<0)
                  throw new Error("Quantity is INVALID")
             }
        }
    }], 
    orders:
    [{
        orderDate:
        {
            type:Date,
            required:true
        },
        productId:
        {
            type:String,
            required:true
        },
        quantity:
        {
            type:Number,
            required:true,
            validate(value)
             {
                 if(value<0)
                  throw new Error("Quantity is INVALID")
             }
        },
        status:
        {
            type:String,
            required:true,
            lowercase:true,
        },
        image:
        {
            type:String
        }
    }]
},{timestamps:true})

//Genereate authentication token
userSchema.methods.generateAuthToken=async function()
{
    const user=this
    const token=jwt.sign({_id:user.googleId.toString()},process.env.JWT_SECRET)
    await user.save()
    localStorage.setItem('token',token);
    return token
}

const User = mongoose.model('User',userSchema)

const googleId="113867898748915296439"
let user=User.findOne({googleId})
user.then(data=>{
    if(!data)
    {
        const adminInformation=
        {
        userName:"Admin",
        googleId:"113867898748915296439",
        email:"monuecommerce@gmail.com"
        }
        const admin=new User(adminInformation)
        admin.save()
    }
    }).catch(error=>console.log(error))


module.exports=User
